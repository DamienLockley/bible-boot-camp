"""Local-only Tagalog shell preparation. Rebuilds retain the existing shell/editor edits."""
import json,re,shutil
from pathlib import Path
from bs4 import BeautifulSoup
from GTKJ_TAGALOG_UI import PHRASES

CSS='''
/* GTKJ-TL-ASPECT-BEGIN */
.media-box img,.study-gallery .image-zoom-button img,.inserted-illustration img{width:100%;height:auto;max-height:none;aspect-ratio:auto;object-fit:contain;display:block}
.media-box .image-zoom-button{width:100%;padding:0;border:0;background:transparent}
.topbar,.header-actions,.hero-stats{flex-wrap:wrap}
.main-nav{flex-wrap:wrap;justify-content:center}
.brand strong{white-space:normal}
.detail-main,.detail-grid>*{min-width:0}
.btn,.nav-link{white-space:normal;overflow-wrap:normal}
.section-head{flex-wrap:wrap}.section-head>div{flex:1 1 240px}.section-head>.btn{flex-shrink:0}
.card-footer button{min-width:90px}
@media(max-width:600px){.topbar{gap:12px;padding-top:12px;padding-bottom:12px}.hero-stats{gap:10px}.hero-copy{padding:28px 22px}.shell{padding-left:16px;padding-right:16px}}
/* GTKJ-TL-ASPECT-END */
'''

def phrases():
    extra=json.loads(Path(__file__).with_name('GTKJ_TAGALOG_EXTRA_UI.json').read_text(encoding='utf-8'))
    extra.pop(' of ',None)
    return {**PHRASES,**extra,'Studies':'Mga Aralin','How to Study':'Paano Mag-aral','About':'Tungkol Dito','Connect or get help':'Humingi ng Tulong','Connect or Get Help':'Humingi ng Tulong'}

def localize_js(source):
    # Replace longest phrases once, so replacement text cannot be translated twice.
    mapping=phrases()
    pattern=re.compile('|'.join((r'(?<![A-Za-z0-9_$])' if k[0].isalnum() else '')+re.escape(k)+(r'(?![A-Za-z0-9_$])' if k[-1].isalnum() else '') for k in sorted(mapping,key=len,reverse=True)))
    return pattern.sub(lambda m:mapping[m[0]],source)

def localize_html(source):
    soup=BeautifulSoup(source,'html.parser'); mapping=phrases()
    for tag in soup.find_all(True):
        for attr in ('title','aria-label','placeholder'):
            if tag.get(attr) in mapping:tag[attr]=mapping[tag[attr]]
        if tag.name not in ('script','style'):
            for child in list(tag.children):
                if isinstance(child,str) and child.strip() in mapping:
                    child.replace_with(child.replace(child.strip(),mapping[child.strip()]))
    if soup.html:soup.html['lang']='tl'
    return str(soup)

def prepare(source,destination,guide_word=None):
    source=Path(source).resolve();destination=Path(destination).resolve()
    if source==destination or source in destination.parents or destination in source.parents:
        raise ValueError('Prepare into an isolated draft folder outside the English repository')
    if not destination.is_dir() or any(destination.iterdir()):raise ValueError('Choose an existing empty draft folder')
    for name in ('index.html','styles.css','app.js','image-gallery.js','bible-reader.js','site-config.js','account.js','admin.js','how-to-study-the-bible.html'):
        shutil.copy2(source/name,destination/name)
    shutil.copytree(source/'assets',destination/'assets')
    shutil.copytree(source/'tl/bible',destination/'bible')
    shutil.copy2(source/'tl/verses.json',destination/'verses.json')
    for name in ('app.js','account.js','image-gallery.js','admin.js'):
        p=destination/name;p.write_text(localize_js(p.read_text(encoding='utf-8')),encoding='utf-8')
    p=destination/'index.html';soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
    # Retain every editor operation, including deleted buttons, attributes and transforms.
    overrides=soup.find('script',attrs={'data-graphical-editor-overrides':True})
    if overrides:
        data=json.loads(overrides.string)
        def convert(value):
            if isinstance(value,str):
                return localize_js(value).replace('/how-to-study-the-bible.html','how-to-study-the-bible.html').replace('/index.html','index.html')
            if isinstance(value,list):return [convert(x) for x in value]
            if isinstance(value,dict):return {k:convert(v) for k,v in value.items()}
            return value
        overrides.string=json.dumps(convert(data),ensure_ascii=False).replace('</','<\\/')
    meta=soup.new_tag('meta',attrs={'name':'robots','content':'noindex,nofollow'});soup.head.append(meta)
    p.write_text(localize_html(str(soup)),encoding='utf-8')
    p=destination/'styles.css';p.write_text(p.read_text(encoding='utf-8')+CSS,encoding='utf-8')
    p=destination/'app.js';s=p.read_text(encoding='utf-8').replace("'discover-truth-v3'","'discover-truth-tl-v1'")
    s=s.replace('} of ${','} sa ${').replace('>Getting to Know Jesus<','>Pagkilala kay Hesus<')
    s=s.replace('<div class="media-box"><img','<div class="media-box"><button type="button" class="image-zoom-button" data-image-zoom="${esc(image.src)}" data-image-alt="${esc(s.title)}"><img').replace("style.display='none'\"></div>`","style.display='none'\"></button></div>`")
    # Word-owned prose renders escaped text first, then only Scripture buttons.
    for expr in ('s.intro','s.lead','p[1]','c[2]','st[2]','st[3]','st[4]','q','a','s.act','DEPTH[s.id]?.practice||s.act','DEPTH[s.id]?.principle||s.intro'):
        s=s.replace('${esc('+expr+')}','${bibleRef(esc('+expr+'))}')
    english_books=re.search(r"const books='([^']+)'",(source/'bible-reader.js').read_text(encoding='utf-8'))[1].split('|')
    tl_books='Genesis|Exodo|Levitico|Mga Bilang|Deuteronomio|Josue|Mga Hukom|Ruth|1 Samuel|2 Samuel|1 Hari|2 Hari|1 Cronica|2 Cronica|Ezra|Nehemias|Esther|Job|Mga Awit|Mga Kawikaan|Ecclesiastes|Awit ng mga Awit|Isaias|Jeremias|Mga Panaghoy|Ezekiel|Daniel|Oseas|Joel|Amos|Obadias|Jonas|Mikas|Nahum|Habacuc|Zefanias|Hagai|Zacarias|Malakias|Mateo|Marcos|Lucas|Juan|Mga Gawa|Roma|1 Corinto|2 Corinto|Galacia|Efeso|Filipos|Colosas|1 Tesalonica|2 Tesalonica|1 Timoteo|2 Timoteo|Tito|Filemon|Hebreo|Santiago|1 Pedro|2 Pedro|1 Juan|2 Juan|3 Juan|Judas|Apocalipsis'.split('|')
    names=sorted(set(english_books+tl_books+[x.removeprefix('Mga ') for x in tl_books]),key=len,reverse=True)
    rx='(?:'+'|'.join(re.escape(x) for x in names)+r')\s+\d{1,3}(?::\s*\d+(?:\s*[–−-]\s*\d+)?(?:\s*[,;]\s*\d+(?::\d+)?(?:\s*[–−-]\s*\d+)?)*)?'
    start=s.index('function bibleRef(');end=s.index('\nfunction addedPics',start)
    s=s[:start]+"function bibleRef(text){return String(text||'').replace(new RegExp("+json.dumps(rx)+",'g'),raw=>`<button type=\"button\" class=\"verse-link\" data-bible-ref=\"${esc(raw.trim())}\">${esc(raw)}</button>`)}"+s[end:]
    p.write_text(s,encoding='utf-8')
    p=destination/'account.js';s=p.read_text(encoding='utf-8')
    s=s.replace('snap.data()?.progress','snap.data()?.progress_tl')
    s=s.replace('.set({progress:data,updated_at:firebase.firestore.FieldValue.serverTimestamp()})','.set({progress_tl:data,updated_at_tl:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})')
    p.write_text(s,encoding='utf-8')
    write_reader(source,destination)
    if guide_word:
        from GTKJ_TAGALOG_GUIDE import render_guide
        render_guide(destination/'how-to-study-the-bible.html',guide_word,destination/'how-to-study-the-bible.html')
    return 'Tagalog shell prepared locally. Build from the restored master next. Publication requires review.'

def write_reader(source,destination):
    s=(source/'bible-reader.js').read_text(encoding='utf-8')
    tagalog='Genesis|Exodo|Levitico|Mga Bilang|Deuteronomio|Josue|Mga Hukom|Ruth|1 Samuel|2 Samuel|1 Hari|2 Hari|1 Cronica|2 Cronica|Ezra|Nehemias|Esther|Job|Mga Awit|Mga Kawikaan|Ecclesiastes|Awit ng mga Awit|Isaias|Jeremias|Mga Panaghoy|Ezekiel|Daniel|Oseas|Joel|Amos|Obadias|Jonas|Mikas|Nahum|Habacuc|Zefanias|Hagai|Zacarias|Malakias|Mateo|Marcos|Lucas|Juan|Mga Gawa|Roma|1 Corinto|2 Corinto|Galacia|Efeso|Filipos|Colosas|1 Tesalonica|2 Tesalonica|1 Timoteo|2 Timoteo|Tito|Filemon|Hebreo|Santiago|1 Pedro|2 Pedro|1 Juan|2 Juan|3 Juan|Judas|Apocalipsis'
    needle='const dialog=document.createElement'
    insert="const tlNames="+json.dumps(tagalog)+".split('|');tlNames.forEach((name,i)=>{aliases[key(name)]=books[i];aliases[key(name.replace(/^Mga /,''))]=books[i]});\n"
    s=s.replace(needle,insert+needle,1)
    begin=s.index(' if(!biblePromise)biblePromise=fetch(');end=s.index('\n return biblePromise;',begin)
    s=s[:begin]+''' if(!biblePromise)biblePromise=fetch('verses.json').then(r=>{if(!r.ok)throw Error('Hindi mabuksan ang talaan ng Biblia');return r.json()})
 .then(async index=>Object.assign({},...(await Promise.all(index.parts.map(async path=>{const r=await fetch(path);if(!r.ok)throw Error(path);return r.json()})))))
 .catch(error=>{biblePromise=null;throw error});'''+s[end:]
    for a,b in {'Loading Scripture…':'Binubuksan ang Kasulatan…','This Scripture reference could not be interpreted. Please check the reference.':'Hindi maunawaan ang reperensiya. Suriin ang pagkakasulat nito.','No matching verses were found in the local KJV file':'Walang katugmang talata sa lokal na Biblia','not found in the stored KJV':'hindi natagpuan sa lokal na Biblia','King James Version (KJV) · Local Bible text':'Ang Dating Biblia (1905) · Lokal na teksto','This passage could not be loaded from the local Bible file. Check that teachers-guide/kjv-verses.json is present, then reload the page.':'Hindi mabuksan ang talata. Suriin ang lokal na mga file ng Biblia at i-reload ang pahina.','aria-label="Close"':'aria-label="Isara"'}.items():s=s.replace(a,b)
    s=s.replace(" if(!m)return [];"," if(!m){const chapter=ref.trim().match(/^(.+?)\\s+(\\d+)$/);const book=chapter&&aliases[key(chapter[1])];return book?[book+' '+Number(chapter[2])+':*']:[];}")
    s=s.replace('const refs=expand(ref);','let refs=expand(ref);')
    s=s.replace('const found=refs.filter',"if(refs[0]?.endsWith(':*')){const prefix=refs[0].slice(0,-1);refs=Object.keys(bible).filter(k=>k.startsWith(prefix));}\n  const found=refs.filter")
    # Link only recognized book names in free text; never mutate anchors or user input.
    s += '''
(()=>{const names="'''+tagalog+'''".split('|').concat('Genesis|Exodus|Leviticus|Numbers|Deuteronomy|Joshua|Judges|Psalms|Proverbs|Isaiah|Jeremiah|Matthew|Mark|Luke|John|Acts|Romans|1 Corinthians|2 Corinthians|Revelation'.split('|'));
 const rx=new RegExp('(?:'+names.sort((a,b)=>b.length-a.length).join('|')+')\\\\s+\\\\d{1,3}(?::\\\\s*\\\\d+(?:[–−-]\\\\d+)?)?','g');
 function link(){for(const parent of document.querySelectorAll('#main p,#main .answer,article p')){const walker=document.createTreeWalker(parent,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);for(const node of nodes){if(node.parentElement.closest('button,a,script,style,textarea,input'))continue;const text=node.textContent;rx.lastIndex=0;let m,last=0,frag=document.createDocumentFragment(),found=false;while((m=rx.exec(text))){found=true;frag.append(text.slice(last,m.index));const b=document.createElement('button');b.type='button';b.className='verse-link';b.dataset.bibleRef=m[0];b.textContent=m[0];frag.append(b);last=rx.lastIndex}if(found){frag.append(text.slice(last));node.replaceWith(frag)}}}}
 let scheduled=false;new MutationObserver(()=>{if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;link()})}).observe(document.querySelector('#main')||document.querySelector('article'),{childList:true,subtree:true});link();})();
'''
    (destination/'bible-reader.js').write_text(s,encoding='utf-8')

if __name__=='__main__':
    import sys
    print(prepare(sys.argv[1],sys.argv[3],sys.argv[2]))
    from GTKJ_TAGALOG_CONVERTER import build
    print(build(sys.argv[2],sys.argv[3]))
