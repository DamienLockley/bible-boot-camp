"""Produce GTKJ study data from a fully translated Tagalog Word master.

Outputs only study data. Does not alter English pages, live files, or image assets.
Requires the explicit TRANSLATION_STATUS: COMPLETE document marker to avoid
publishing untranslated English placeholders as a purported Filipino edition.
"""
import json, re, sys
from pathlib import Path
from docx import Document

FIELDS={'TITLE','TAG','LEAD','INTRO','VERSES','IDEA_TITLE','IDEA_TEXT','IDEA_VERSES',
        'CONNECTION_TITLE','CONNECTION_VERSES','CONNECTION_TEXT','PRINCIPLE',
        'STEP_REF','STEP_TITLE','STEP_TEXT','STEP_QUESTION','STEP_ANSWER',
        'QA_QUESTION','QA_ANSWER','ACTION','PRACTICE'}
STUDY_RE=re.compile(r'^STUDY\s+(\d{2})\s*\|\s*(.+?)\s*$',re.I)


def parse_master(path):
    paras=[p.text.strip() for p in Document(path).paragraphs if p.text.strip()]
    if not any(x.upper()=='TRANSLATION_STATUS: COMPLETE' for x in paras):
        raise ValueError('Tagalog Word master is not marked TRANSLATION_STATUS: COMPLETE. '
                         'Finish/review all 28 Tagalog translations before building. '
                         'The current English master is deliberately not accepted.')
    studies=[]; introduction=[]; curr=None; rows=[]
    for line in paras:
        m=STUDY_RE.match(line)
        if m:
            if curr:studies.append((curr,rows))
            curr=(int(m.group(1)), 'word' if int(m.group(1))==1 and m.group(2).strip().lower()=='the word' else m.group(2).strip());rows=[]
            continue
        if curr is None:introduction.append(line)
        else:
            if line.startswith('[[CWEX_IMG_') or line.startswith('Illustration ('):continue
            name, sep, value=line.partition(':')
            if sep and name in FIELDS:rows.append((name,value.strip()))
    if curr:studies.append((curr,rows))
    if [s[0][0] for s in studies]!=list(range(1,29)):
        raise ValueError('Expected 28 studies in order STUDY 01 through STUDY 28; found: '+str([x[0][0] for x in studies]))
    if not any(x.startswith('START HERE | introduction') for x in introduction):
        raise ValueError('Missing START HERE | introduction heading')
    if any(sum(k==key for k,_ in rows)!=6 for _,rows in studies for key in ['STEP_REF','STEP_TITLE','STEP_TEXT','STEP_QUESTION','STEP_ANSWER']):
        raise ValueError('Each study requires exactly six complete STEP groups')
    return introduction,studies


def build(doc_path,out):
    intro,raw=parse_master(doc_path)
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    studies=[];depth={};connections={}
    for (number,sid),rows in raw:
        d={}
        for key,value in rows:d.setdefault(key,[]).append(value)
        def one(k):
            if len(d.get(k,[]))!=1:raise ValueError(f'Study {number:02d}: expected one {k}')
            return d[k][0]
        def grouped(keys):
            vals=[d.get(k,[]) for k in keys]
            if len({len(v) for v in vals})!=1:raise ValueError(f'Study {number:02d}: mismatched '+str(keys))
            return [list(t) for t in zip(*vals)]
        if len(grouped(('IDEA_TITLE','IDEA_TEXT','IDEA_VERSES')))!=3:raise ValueError('Study '+str(number)+' needs three IDEAs')
        if len(grouped(('CONNECTION_TITLE','CONNECTION_VERSES','CONNECTION_TEXT')))!=4:raise ValueError('Study '+str(number)+' needs four CONNECTIONs')
        studies.append({'id':sid,'title':one('TITLE'),'tag':one('TAG'),'lead':one('LEAD'),
                        'intro':one('INTRO'),'verses':[x.strip() for x in re.split(r';\s*',one('VERSES')) if x.strip()],
                        'ideas':grouped(('IDEA_TITLE','IDEA_TEXT','IDEA_VERSES')),
                        'qa':grouped(('QA_QUESTION','QA_ANSWER')),'act':one('ACTION')})
        depth[sid]={'principle':one('PRINCIPLE'),
                    'steps':grouped(('STEP_REF','STEP_TITLE','STEP_TEXT','STEP_QUESTION','STEP_ANSWER')),
                    'practice':one('PRACTICE')}
        connections[sid]=grouped(('CONNECTION_TITLE','CONNECTION_VERSES','CONNECTION_TEXT'))
    # START HERE section uses plain heading + paragraph pairs like the English master.
    i=intro.index('START HERE | introduction')+1
    headings=['Welcome','How these','Read the Bible','Your personal','A simple']
    before=[]
    for line in intro[i:]:
        if line.startswith('TRANSLATION_STATUS:'):continue
        if line.startswith('How Do You Study') or line.startswith('Paano Mag-aral'):break
        before.append(line)
    # Deliberately require exactly five section headings and paragraphs;
    # no guessing from translated headings.
    if len(before)<10:raise ValueError('Start Here introduction incomplete: expected five heading/paragraph pairs')
    sections=[{'heading':before[i],'paragraphs':[before[i+1]]} for i in range(0,10,2)]
    # JSON data matches existing English GTKJ renderer interfaces.
    for name,expr,obj in [('lessons.js','STUDIES',studies),('lesson-depth.js','DEPTH',depth),
                          ('principles.js','CONNECTIONS',connections),
                          ('start-here.js','START_HERE',{'title':'Magsimula Dito','sections':sections})]:
        (out/name).write_text('// GENERATED from reviewed Tagalog Word master — do not hand edit\nconst '+expr+' = '+json.dumps(obj,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
    export_images(doc_path,out,studies)
    return f'Tagalog data built: {len(studies)} studies, 5 Start Here sections. No English files modified.'


def export_images(doc_path,out,studies):
    """Map drawings by their enclosing STUDY section, never ZIP entry order."""
    import hashlib
    from docx.oxml.ns import qn
    doc=Document(doc_path); by_number={}; current=None
    for para in doc.paragraphs:
        match=STUDY_RE.match(para.text.strip())
        if match: current=int(match.group(1))
        if para.text.strip().startswith('BIBLE STUDY GUIDE |'): current=None
        for drawing in para._p.iter(qn('a:blip')):
            rid=drawing.get(qn('r:embed'))
            if rid:
                if current is None: raise ValueError('Image outside a STUDY section')
                by_number.setdefault(current,[]).append(doc.part.related_parts[rid])
    if any(len(by_number.get(n,[]))!=1 for n in range(1,29)):
        raise ValueError('Restore exactly one original illustration in each of the 28 STUDY sections before image import')
    image_map={};manifest=[]
    for number,study in enumerate(studies,1):
        part=by_number[number][0];extension=Path(str(part.partname)).suffix.lower()
        if extension not in ('.png','.jpg','.jpeg','.gif','.webp'):raise ValueError('Unsupported study image: '+extension)
        rel='assets/word-master/'+study['id']+extension
        target=Path(out)/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(part.blob)
        image_map[study['id']]={'src':rel,'alt':'Larawan: '+study['title']}
        manifest.append({'study':study['id'],'path':rel,'sha256':hashlib.sha256(part.blob).hexdigest()})
    (Path(out)/'image-map.js').write_text('const BIBLEWORLD_IMAGES = '+json.dumps(image_map,ensure_ascii=False,indent=2)+';\nconst STUDY_INLINE_IMAGES = {};\n',encoding='utf-8')
    (Path(out)/'word-images.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    if len(sys.argv)!=3:sys.exit('Usage: python GTKJ_TAGALOG_CONVERTER.py TAGALOG_MASTER.docx OUTPUT_DIR')
    try:print(build(sys.argv[1],sys.argv[2]))
    except Exception as e:sys.exit('TAGALOG BUILD BLOCKED: '+str(e))
