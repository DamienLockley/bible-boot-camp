"""Run: python GTKJ_TAGALOG_REGRESSION.py ENGLISH_ROOT RESTORED_MASTER.docx"""
from pathlib import Path
import hashlib,json,re,sys,tempfile
from bs4 import BeautifulSoup
from GTKJ_TAGALOG_SITE import prepare
from GTKJ_TAGALOG_CONVERTER import build,parse_master
from GTKJ_TAGALOG_GUIDE import render_guide

def run(source,master):
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp)/'draft';out.mkdir();prepare(source,out,master);build(master,out)
        _,studies=parse_master(master)
        assert len(studies)==28
        assert sum(sum(k=='STEP_REF' for k,_ in rows) for _,rows in studies)==168
        assert sum(sum(k=='CONNECTION_TITLE' for k,_ in rows) for _,rows in studies)==112
        images=json.loads((out/'word-images.json').read_text(encoding='utf-8'));assert len(images)==28
        for image in images:assert hashlib.sha256((out/image['path']).read_bytes()).hexdigest()==image['sha256']
        def hashes():return {str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
        before=hashes();build(master,out);guide=out/'how-to-study-the-bible.html';render_guide(guide,master,guide);assert before==hashes()
        text=guide.read_text(encoding='utf-8').replace('</body>','<aside id="editor-sentinel">Custom</aside></body>');guide.write_text(text,encoding='utf-8')
        render_guide(guide,master,guide);assert 'id="editor-sentinel"' in guide.read_text(encoding='utf-8')
        soup=BeautifulSoup(guide.read_text(encoding='utf-8'),'html.parser');assert len([h for h in soup.select('article h2') if re.match(r'^\d+\.',h.text)])==10
        index=BeautifulSoup((out/'index.html').read_text(encoding='utf-8'),'html.parser')
        for tag,attr in [('script','src'),('link','href')]:
            for node in index.find_all(tag):
                path=node.get(attr,'').split('?')[0]
                if path and not path.startswith(('https:','http:','#')):assert (out/path).is_file(),path
        css=(out/'styles.css').read_text(encoding='utf-8');assert 'height:auto;max-height:none;aspect-ratio:auto;object-fit:contain' in css
        assert 'discover-truth-tl-v1' in (out/'app.js').read_text(encoding='utf-8')
        account=(out/'account.js').read_text(encoding='utf-8');assert 'progress_tl:data' in account and '{merge:true}' in account
        print('PASS: structure, image hashes, repeat build, editor retention, guide, asset paths, aspect CSS, progress isolation')
if __name__=='__main__':run(Path(sys.argv[1]),Path(sys.argv[2]))
