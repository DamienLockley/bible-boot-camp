"""V23.7-compatible preparation of an isolated Tagalog draft."""
from GTKJ_TAGALOG_SITE import prepare
if __name__=='__main__':
    import sys
    print(prepare(sys.argv[1],sys.argv[2]))
