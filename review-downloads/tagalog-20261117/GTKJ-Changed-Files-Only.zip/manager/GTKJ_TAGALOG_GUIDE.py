"""Copy the current English guide DESIGN and insert reviewed Filipino guide text.

Use only on an isolated Tagalog draft. The English original remains untouched.
"""
from pathlib import Path
from docx import Document
from bs4 import BeautifulSoup, Comment
import re


def render_guide(english_html, tagalog_word, output_html):
    guide=Document(str(tagalog_word))
    paras=[p for p in guide.paragraphs if p.text.strip()]
    # Reviewed standalone: locate its Part 2 heading. Future Tagalog master:
    # locate the distinct How-to-Study section after the 28th study.
    starts=[i for i,p in enumerate(paras) if p.text.strip().startswith('Bahagi 2 — Paano Mag-aral') or
            p.text.strip() in ('Paano Mag-aral ng Biblia','How Do You Study the Bible?')]
    if not starts:raise ValueError('Cannot locate Tagalog How-to-Study section in Word')
    section=paras[starts[-1]+1:]
    # Any tagged review footer is never published.
    section=[p for p in section if not p.text.startswith(('GTKJ · Tagalog working','Translation in progress'))]
    titles=[p for p in section if p.style.name.lower().startswith('heading') and re.match(r'^\d+\.',p.text.strip())]
    if len(titles)!=10:
        raise ValueError('Tagalog How-to-Study guide must contain all ten numbered principles (found '+str(len(titles))+')')
    soup=BeautifulSoup(Path(english_html).read_text(encoding='utf-8'),'html.parser')
    article=soup.find('article',id='top')
    if article is None:raise ValueError('English guide changed: article#top is missing; refused unsafe replacement')
    h1=article.find('h1')
    if h1:h1.string='Paano Mag-aral ng Biblia'
    eyebrow=article.find(class_='eyebrow')
    if eyebrow:eyebrow.string='Gabay sa Pag-aaral ng Biblia'
    subtitle=article.find('p',class_='subtitle')
    if subtitle is None:raise ValueError('English guide changed: subtitle missing')
    if not section or section[0].style.name.lower().startswith('heading'):
        raise ValueError('Tagalog Word guide is missing its opening subtitle')
    subtitle.string=section[0].text.strip()
    # First Tagalog draft render creates bounded Word-owned text. Subsequent
    # rebuilds replace only that bounded region, preserving HTML Editor changes
    # elsewhere in the page and its original navigation/scripts/CSS.
    start=None;end=None
    for node in article.descendants:
        if isinstance(node,Comment) and str(node).strip()=='GTKJ-TL-WORD-BEGIN':start=node
        if isinstance(node,Comment) and str(node).strip()=='GTKJ-TL-WORD-END':end=node
    if (start is None)!=(end is None):
        raise ValueError('Damaged Tagalog Word sync marker. Refused to overwrite custom HTML.')
    first_build=start is None
    if first_build:
        for item in list(article.children):
            if getattr(item,'name',None) and item not in (h1.parent,subtitle):item.extract()
        start=Comment('GTKJ-TL-WORD-BEGIN');article.append(start)
        end=Comment('GTKJ-TL-WORD-END');article.append(end)
    else:
        node=start.next_sibling
        while node is not None and node is not end:
            following=node.next_sibling
            node.extract();node=following
        if node is None:raise ValueError('Tagalog Word sync markers are not siblings; refused unsafe edit')
    for para in section[1:]:
        content=para.text.strip()
        if not content:continue
        heading=para.style.name.lower().startswith('heading')
        tag=soup.new_tag('h2' if heading else 'p')
        tag.string=content
        end.insert_before(tag)
    # Translate only labels existing in the English chrome. Keep nav links relative.
    for link in soup.find_all('a'):
        t=link.get_text(' ',strip=True)
        if 'Back to Home' in t:link.string='← Bumalik sa Unang Pahina'
        elif 'Begin Study 1' in t:link.string='Simulan ang Aralin 1 →'
        elif t in ('Tagalog','🇵🇭 Tagalog'):
            link['href']='../index.html';link.string='English'
    for node in soup.find_all(string=True):
        if getattr(node,'parent',None) and node.parent.name=='title':node.replace_with('Paano Mag-aral ng Biblia | Pagkilala kay Hesus')
    if soup.html:soup.html['lang']='tl'
    # Replace the English-only KJV popup with the same real Tagalog reader.
    for script in list(soup.find_all('script')):
        if not script.get('src') and ('kjv' in script.get_text().lower()):script.decompose()
    if not soup.find('script',src='bible-reader.js'):
        script=soup.new_tag('script',src='bible-reader.js');soup.body.append(script)
    if not soup.find(id='tl-guide-navigation'):
        nav=soup.new_tag('nav',id='tl-guide-navigation')
        for label,url in [('← Bumalik sa Unang Pahina','index.html'),('Simulan ang Aralin 1 →','index.html#study=word'),('Humingi ng Tulong','index.html#help')]:
            link=soup.new_tag('a',href=url);link.string=label;nav.append(link);nav.append(' ')
        article.append(nav)
    if not soup.find('style',id='tl-reader-style'):
        style=soup.new_tag('style',id='tl-reader-style')
        style.string='.bible-reader-dialog{width:min(720px,92vw);max-height:85vh;overflow:auto;padding:24px;border-radius:16px}.bible-reader-close{float:right}.verse-link{background:none;border:0;color:#18594b;text-decoration:underline;cursor:pointer;font:inherit;padding:0}#tl-guide-navigation{display:flex;flex-wrap:wrap;gap:16px;margin-top:24px}'
        soup.head.append(style)
    from GTKJ_TAGALOG_SITE import localize_html
    Path(output_html).write_text(localize_html(str(soup)),encoding='utf-8')
    return f'Rendered complete Tagalog guide: {len(titles)} principles, from reviewed Word into isolated English-style page.'
