# Test report — local Tagalog draft

Automated checks ran in headless Chromium against an HTTP-served draft. The current English repository was used as the design source. Screenshots compare the two at 1440, 1024 and 390 pixels. Longer translated text creates different wrapping and page heights; exact pixel identity is not claimed.

## Passed

- 28 ordered studies, unchanged renderer study IDs, 168 guided readings, 112 connections, 84 Q&A pairs, all application/practice fields; five complete Start Here sections and ten numbered guide principles.
- 28 embedded images mapped by their enclosing study, with byte hashes retained. All 28 render with natural aspect ratios. Landscape, portrait and square swaps passed. Main illustration zoom works.
- All 28 study routes render with six checkpoints and four connections each. Search, empty-result state, notes persistence, lesson completion/unlocks, journey, About, Start Here and guide navigation exercised.
- Real Ang Dating Biblia passage popup and whole-chapter `1 Corinto 11` popup tested. No English KJV fallback is used. The latest guide examples are present in the restored Word master and rendered guide.
- No horizontal page overflow on the home or study page at 1440, 1024 or 390 pixels; no browser JavaScript exceptions or HTTP response failures during the recorded checks.
- The 17 original Graphical HTML Editor operations remain in the translated shell, including deleted controls, style transforms and custom pasted links. The custom Start Here guide link resolves inside the Tagalog folder. Bounded guide rebuilds preserve an injected editor sentinel outside the Word region. Index bytes remain untouched by data rebuilds.
- Two consecutive rebuilds were byte-for-byte stable, including generated datasets, images and guide. Rebuilding did not alter English files. The final local feature commit changes only `tl/`.
- Static asset references, image-manifest hashes, retained image sizing rules and progress isolation are checked by the included reproducible regression script.
- Isolated Firebase mocks passed sign-in/out, loading Tagalog cloud notes, saving Tagalog cloud progress with merge, preservation of the English progress field, and password-reset request routing. Contact submission/nonce confirmation passed with an intercepted mock endpoint. These tests sent no real email and wrote no live user data.

## Still required before publication

- Native-speaker review of every translation, caption and new interface label. The supplied master explicitly requests language/live-site review. No certification of naturalness is claimed.
- Real Firebase test-account sign-in/out, email verification and password reset/delivery, cross-device persistence, and permission to merge the additional Tagalog fields under the existing rules. Mock success cannot establish production authorization.
- Real contact/email delivery and server-side validation. Only the existing client workflow and mocked confirmation were exercised.
- Authenticated administrator permission/list/access updates, real native share sheet, progress download/import end-to-end, and all rare Firebase/server error responses. These were retained but not comprehensively exercised.
- Interactive user review on an actual iPhone and other target devices, including keyboard, assistive technology and user-edited layouts. Automated viewport screenshots are not physical-device testing.
- Native Windows V23.7 manager UI execution, settings restoration and local server controls. The GUI/settings/English converters were not edited. Python build modules compiled and the converter/setup/guide/regression pipeline executed here.
- Offline/PWA behavior is not claimed: the current root shell has no PWA manifest/service-worker references to duplicate. No new offline contract was introduced.

## Scope and limitations

The complete local draft is reviewable; it is not approved for publication. Existing unused legacy `tl/studies.json` and `tl/README.md` are retained in the repository patch but are no longer loaded by the new shell. The standalone draft includes only the current implementation and necessary assets. Contact option values stay in their existing canonical form while labels are translated.

Delivery packaging was saved under `/workspace/work/deliverables/`. The session's designated `/codex/.../output` directory could not be created because the filesystem returned “Read-only file system”; this prevents normal downloadable output links in this chat. The files themselves and local feature branch remain available in the workspace.
